# Device Service Examples

Please clone device virtual as an example from https://github.com/edgexfoundry/device-virtual-go.git